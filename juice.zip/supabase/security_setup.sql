-- SECURITY SETUP: Enable Row Level Security (RLS)
-- This script locks down your database so only authenticated users can access the data.

-- 1. Enable RLS on all tables
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bill_items ENABLE ROW LEVEL SECURITY;

-- 2. Create Policies for CATEGORIES
CREATE POLICY "Enable read for authenticated users only" ON public.categories
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable insert for authenticated users only" ON public.categories
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Enable update for authenticated users only" ON public.categories
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Enable delete for authenticated users only" ON public.categories
  FOR DELETE TO authenticated USING (true);

-- 3. Create Policies for MENU_ITEMS
CREATE POLICY "Enable read for authenticated users only" ON public.menu_items
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable insert for authenticated users only" ON public.menu_items
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Enable update for authenticated users only" ON public.menu_items
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Enable delete for authenticated users only" ON public.menu_items
  FOR DELETE TO authenticated USING (true);

-- 4. Create Policies for BILLS
CREATE POLICY "Enable read for authenticated users only" ON public.bills
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable insert for authenticated users only" ON public.bills
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Enable update for authenticated users only" ON public.bills
  FOR UPDATE TO authenticated USING (true);

-- 5. Create Policies for BILL_ITEMS
CREATE POLICY "Enable read for authenticated users only" ON public.bill_items
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable insert for authenticated users only" ON public.bill_items
  FOR INSERT TO authenticated WITH CHECK (true);
