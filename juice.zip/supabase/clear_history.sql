-- DANGER: This script will delete ALL transaction history.
-- Use this ONLY if you want to reset your sales data for a fresh start.

-- 1. Delete all items associated with bills first (due to foreign key constraints)
DELETE FROM public.bill_items;

-- 2. Delete all bills
DELETE FROM public.bills;
