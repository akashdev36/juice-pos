-- ==========================================
-- MIGRATION: Add category_id to menu_items
-- Run this in your Supabase SQL Editor
-- ==========================================

-- 1. Add category_id column to menu_items
ALTER TABLE public.menu_items 
ADD COLUMN IF NOT EXISTS category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL;

-- 2. Migrate existing data: set category_id based on current category name
UPDATE public.menu_items mi
SET category_id = c.id
FROM public.categories c
WHERE mi.category = c.name
  AND mi.category_id IS NULL;

-- 3. (Optional) Drop the old category text column after verification
-- Uncomment the line below AFTER confirming the migration works:
-- ALTER TABLE public.menu_items DROP COLUMN IF EXISTS category;
