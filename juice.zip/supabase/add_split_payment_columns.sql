-- Add columns for split payment support
ALTER TABLE public.bills ADD COLUMN IF NOT EXISTS cash_amount NUMERIC DEFAULT 0;
ALTER TABLE public.bills ADD COLUMN IF NOT EXISTS upi_amount NUMERIC DEFAULT 0;

-- Update the payment_method constraint if any (Supabase usually uses text)
-- If there are existing bills, we might want to populate these columns based on payment_method
UPDATE public.bills 
SET cash_amount = total_amount 
WHERE payment_method = 'Cash' AND cash_amount = 0;

UPDATE public.bills 
SET upi_amount = total_amount 
WHERE payment_method = 'UPI' AND upi_amount = 0;
