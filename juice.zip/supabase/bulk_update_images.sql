-- ============================================================
-- FIXED IMAGE UPDATE SCRIPT (Using LoremFlickr - More Stable)
-- ============================================================

-- 1. DYNAMIC UPDATE (Handles EVERY item)
-- This uses LoremFlickr which is very reliable for keyword images.
UPDATE public.menu_items
SET image_url = 'https://loremflickr.com/400/400/' || REPLACE(LOWER(name), ' ', ',');

-- 2. CATEGORY THEMES (For better accuracy)
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/mojito,drink' WHERE category_id IN (SELECT id FROM categories WHERE name = 'Mojito Delights');
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/milkshake,glass' WHERE category_id IN (SELECT id FROM categories WHERE name = 'Milk Shake');
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/milkshake,icecream' WHERE category_id IN (SELECT id FROM categories WHERE name = 'Fruit Shake with Ice Cream');
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/thickshake' WHERE category_id IN (SELECT id FROM categories WHERE name = 'Cream Rush Shakes');
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/falooda,dessert' WHERE name LIKE '%Falooda%';
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/sandwich,food' WHERE category_id IN (SELECT id FROM categories WHERE name = 'Sandwich');
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/lassi,drink' WHERE category_id IN (SELECT id FROM categories WHERE name = 'Lassi');
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/momos,dumplings' WHERE name LIKE '%Momo%';
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/maggi,noodles' WHERE name LIKE '%Maggi%';
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/fries,chips' WHERE name LIKE '%Fries%';
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/food,snack' WHERE category_id IN (SELECT id FROM categories WHERE name = 'Combos');

-- 3. SPECIFIC KEYWORDS (Fixing common juice names)
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/orange,juice' WHERE name LIKE '%Orange%';
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/strawberry' WHERE name LIKE '%Strawberry%';
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/banana' WHERE name LIKE '%Banana%';
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/apple,fruit' WHERE name LIKE '%Apple%';
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/mango,fruit' WHERE name LIKE '%Mango%';
UPDATE public.menu_items SET image_url = 'https://loremflickr.com/400/400/chocolate,milk' WHERE name LIKE '%Chocolate%';
