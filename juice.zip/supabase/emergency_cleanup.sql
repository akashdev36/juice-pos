-- ============================================================
-- EMERGENCY CLEANUP SCRIPT
-- ============================================================

-- 1. UNDO THE MESS: Remove all placeholder links
-- This will bring back the default 🥤 icon for these items
UPDATE public.menu_items
SET image_url = NULL
WHERE image_url LIKE '%loremflickr.com%' 
   OR image_url LIKE '%unsplash.com%';

-- 2. PROTECT YOUR MANUAL UPLOADS:
-- Any image that starts with your project URL or common storage patterns 
-- will NOT be touched by the command above. 

-- 3. (OPTIONAL) Add placeholders ONLY to items that are still empty:
-- Run this ONLY if you want the placeholders back for the missing ones.
-- UPDATE public.menu_items
-- SET image_url = 'https://loremflickr.com/400/400/' || REPLACE(LOWER(name), ' ', ',')
-- WHERE image_url IS NULL;
