import { ReactNode } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { LayoutDashboard, UtensilsCrossed, Receipt, History, Search, LogOut } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import juiceJungleLogo from "@/assets/juice-jungle-logo.jpg";

interface AppLayoutProps {
  children: ReactNode;
}

const navItems = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/menu", icon: UtensilsCrossed, label: "Menu" },
  { to: "/billing", icon: Receipt, label: "Billing" },
  { to: "/history", icon: History, label: "History" },
];

export function AppLayout({ children }: AppLayoutProps) {
  const location = useLocation();
  const { signOut } = useAuth();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b bg-card shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 shrink-0">
            <div className="bg-primary/10 p-1.5 rounded-xl">
              <img
                src={juiceJungleLogo}
                alt="Juice Jungle"
                className="h-8 w-8 rounded-lg object-cover"
              />
            </div>
            <h1 className="text-xl font-black text-[#1DB954] tracking-tight">
              Juice <span className="text-[#2D3436]">Jungle</span>
            </h1>
          </div>

          {/* Search Bar */}
          <div className="hidden md:flex flex-1 max-w-sm relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
            <Input
              placeholder="Search"
              className="pl-10 h-10 bg-[#F1F3F5] border-none rounded-xl focus-visible:ring-1 focus-visible:ring-primary/20 transition-all"
            />
          </div>

          {/* Navigation */}
          <div className="flex items-center gap-4">
            <nav className="flex gap-2">
              {navItems.map((item) => {
                const isActive = location.pathname === item.to;
                return (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    className={`px-5 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${isActive
                      ? "bg-[#4CAF50] text-white shadow-lg shadow-green-200"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                      }`}
                  >
                    {item.label}
                  </NavLink>
                );
              })}
            </nav>

            <div className="h-8 w-[1px] bg-slate-200 mx-2 hidden md:block" />

            <Button
              variant="ghost"
              size="icon"
              onClick={() => signOut()}
              className="text-slate-600 hover:text-destructive hover:bg-destructive/10 rounded-full h-10 w-10 transition-colors"
              title="Sign Out"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-6 py-6">
        {children}
      </main>
    </div>
  );
}