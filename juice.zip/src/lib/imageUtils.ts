/**
 * Image compression utility for reducing file sizes before upload.
 * Compresses images to approximately 50KB while maintaining quality.
 */

export interface CompressOptions {
    maxWidth?: number;
    maxHeight?: number;
    quality?: number;
    maxSizeKB?: number;
}

const DEFAULT_OPTIONS: CompressOptions = {
    maxWidth: 800,
    maxHeight: 800,
    quality: 0.7,
    maxSizeKB: 50,
};

/**
 * Compresses an image file to a smaller size.
 * @param file - The image file to compress
 * @param options - Compression options
 * @returns A promise that resolves to the compressed file
 */
export async function compressImage(
    file: File,
    options: CompressOptions = {}
): Promise<File> {
    const opts = { ...DEFAULT_OPTIONS, ...options };

    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);

        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;

            img.onload = () => {
                const canvas = document.createElement("canvas");
                let { width, height } = img;

                // Calculate new dimensions while maintaining aspect ratio
                if (width > opts.maxWidth! || height > opts.maxHeight!) {
                    const ratio = Math.min(
                        opts.maxWidth! / width,
                        opts.maxHeight! / height
                    );
                    width = Math.round(width * ratio);
                    height = Math.round(height * ratio);
                }

                canvas.width = width;
                canvas.height = height;

                const ctx = canvas.getContext("2d");
                if (!ctx) {
                    reject(new Error("Could not get canvas context"));
                    return;
                }

                // Draw image with white background (for transparency)
                ctx.fillStyle = "#FFFFFF";
                ctx.fillRect(0, 0, width, height);
                ctx.drawImage(img, 0, 0, width, height);

                // Convert to blob with compression
                canvas.toBlob(
                    (blob) => {
                        if (!blob) {
                            reject(new Error("Could not compress image"));
                            return;
                        }

                        // Create a new file from the blob
                        const compressedFile = new File([blob], file.name, {
                            type: "image/jpeg",
                            lastModified: Date.now(),
                        });

                        console.log(
                            `Image compressed: ${(file.size / 1024).toFixed(1)}KB → ${(compressedFile.size / 1024).toFixed(1)}KB`
                        );

                        resolve(compressedFile);
                    },
                    "image/jpeg",
                    opts.quality
                );
            };

            img.onerror = () => {
                reject(new Error("Could not load image"));
            };
        };

        reader.onerror = () => {
            reject(new Error("Could not read file"));
        };
    });
}
