import { useEffect, useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useBills } from "@/hooks/useBills";
import { useMenuItems } from "@/hooks/useMenuItems";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  Legend,
} from "recharts";
import { IndianRupee, ShoppingCart, Banknote, QrCode, RefreshCw, Package, Calendar, UtensilsCrossed, Tag, Citrus, CupSoda } from "lucide-react";

const CHART_COLORS = [
  "#1DB954", // UI Green
  "#0070F3", // Brand Blue (for differentiation)
  "#F59E0B", // Amber
  "#EF4444", // Red
  "#8B5CF6", // Violet
];

export default function Dashboard() {
  const { todayBills, billItems, last30DaysBills, stats, isLoading } = useBills();
  const { menuItems } = useMenuItems();
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // Auto-refresh timestamp
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdated(new Date());
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  // Calculate hourly sales
  const hourlyData = Array.from({ length: 24 }, (_, hour) => {
    const hourBills = todayBills.filter((bill) => {
      const billHour = new Date(bill.date_time).getHours();
      return billHour === hour;
    });
    const total = hourBills.reduce((sum, bill) => sum + Number(bill.total_amount), 0);
    return {
      hour: `${hour.toString().padStart(2, "0")}:00`,
      sales: total,
    };
  }).filter((d) => d.sales > 0 || new Date().getHours() >= parseInt(d.hour));

  // Top 5 selling items
  const itemSales = billItems.reduce((acc, item) => {
    const menuItem = menuItems.find((m) => m.id === item.menu_item_id);
    if (menuItem) {
      acc[menuItem.name] = (acc[menuItem.name] || 0) + item.quantity;
    }
    return acc;
  }, {} as Record<string, number>);

  const soldItems = Object.entries(itemSales)
    .sort(([, a], [, b]) => b - a)
    .map(([name, quantity]) => ({ name, quantity }));

  // 30-day trend
  const dailyTrend = last30DaysBills.reduce((acc, bill) => {
    const date = bill.business_date;
    acc[date] = (acc[date] || 0) + Number(bill.total_amount);
    return acc;
  }, {} as Record<string, number>);

  const trendData = Object.entries(dailyTrend)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, total]) => ({
      date: new Date(date).toLocaleDateString("en-IN", { day: "2-digit", month: "short" }),
      total,
    }));

  // Payment split
  const paymentData = [
    { name: "Cash", value: stats.cashTotal },
    { name: "UPI", value: stats.upiTotal },
  ].filter((d) => d.value > 0);

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(value);

  return (
    <AppLayout>
      <div className="space-y-8 animate-fade-in">
        {/* Full Width Header & KPI Cards Row */}
        <div className="flex flex-wrap lg:flex-nowrap items-center gap-6 mb-8 w-full overflow-hidden">
          {/* Title & Date Section */}
          <div className="shrink-0">
            <h1 className="text-5xl font-serif text-[#2D3436] mb-1 tracking-tight">Dashboard</h1>
            <div className="flex items-center gap-2 text-muted-foreground text-sm font-semibold">
              <Calendar className="h-4 w-4" />
              <span>
                {new Date().toLocaleDateString("en-US", {
                  weekday: "long",
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </span>
            </div>
          </div>

          {/* Cards Section - Flexible but no wrap for desktop */}
          <div className="flex flex-1 gap-4 min-w-0">
            <Card className="shadow-lg shadow-slate-200/60 border-none bg-white rounded-2xl overflow-hidden h-28 flex items-center flex-1 min-w-0 max-w-[240px]">
              <CardContent className="p-0 pl-4 flex items-center gap-3 w-full">
                <div className="bg-[#E7F6EC] p-3 rounded-2xl shrink-0">
                  <IndianRupee className="h-6 w-6 text-[#1DB954]" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest mb-1 truncate">Sales Today</p>
                  <div className="text-xl font-black text-[#1DB954] truncate">
                    {formatCurrency(stats.salesToday)}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg shadow-slate-200/60 border-none bg-white rounded-2xl h-28 flex items-center flex-1 min-w-0 max-w-[200px]">
              <CardContent className="p-0 pl-4 flex items-center gap-3 w-full">
                <div className="bg-[#E7F6F3] p-3 rounded-2xl shrink-0">
                  <ShoppingCart className="h-6 w-6 text-[#1DB9AC]" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest mb-1 truncate">Orders</p>
                  <div className="text-2xl font-black text-[#2D3436] truncate">{stats.ordersToday}</div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg shadow-slate-200/60 border-none bg-white rounded-2xl h-28 flex items-center flex-1 min-w-0 max-w-[200px]">
              <CardContent className="p-0 pl-4 flex items-center gap-3 w-full">
                <div className="bg-[#E7F6EC] p-3 rounded-2xl shrink-0">
                  <Banknote className="h-6 w-6 text-[#1DB954]" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest mb-1 truncate">Cash Today</p>
                  <div className="text-xl font-black text-[#2D3436] truncate">{formatCurrency(stats.cashTotal)}</div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg shadow-slate-200/60 border-none bg-white rounded-2xl h-28 flex items-center flex-1 min-w-0 max-w-[200px]">
              <CardContent className="p-0 pl-4 flex items-center gap-3 w-full">
                <div className="bg-[#DEEFDE] p-3 rounded-2xl shrink-0">
                  <QrCode className="h-6 w-6 text-[#1DB954]" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest mb-1 truncate">UPI Today</p>
                  <div className="text-xl font-black text-[#2D3436] truncate">{formatCurrency(stats.upiTotal)}</div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg shadow-slate-200/60 border-none bg-white rounded-2xl h-28 flex items-center flex-1 min-w-0 max-w-[200px]">
              <CardContent className="p-3 w-full">
                <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest mb-3 text-center">Order Type</p>
                <div className="grid grid-cols-2 gap-0 divide-x divide-slate-100">
                  <div className="flex flex-col items-center">
                    <UtensilsCrossed className="h-5 w-5 text-[#1DB954] mb-1" />
                    <p className="text-[10px] font-black text-[#1DB954]">Dine: {stats.diningItemsToday}</p>
                  </div>
                  <div className="flex flex-col items-center">
                    <Package className="h-5 w-5 text-slate-400 mb-1" />
                    <p className="text-[10px] font-black text-slate-400">Pcl: {stats.parcelItemsToday}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>


        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-6 pb-8">
          {/* Hourly Sales */}
          <Card className="shadow-lg shadow-slate-200/60 border-none bg-white rounded-2xl">
            <CardHeader>
              <CardTitle className="text-lg font-bold text-[#2D3436]">Hourly Sales Today</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={hourlyData}>
                    <CartesianGrid vertical={false} strokeDasharray="0" stroke="#f0f0f0" />
                    <XAxis
                      dataKey="hour"
                      fontSize={11}
                      axisLine={false}
                      tickLine={false}
                      stroke="#94a3b8"
                    />
                    <YAxis
                      fontSize={11}
                      axisLine={false}
                      tickLine={false}
                      stroke="#94a3b8"
                    />
                    <Tooltip
                      cursor={{ fill: '#f8fafc' }}
                      formatter={(value: number) => formatCurrency(value)}
                      contentStyle={{
                        backgroundColor: "white",
                        border: "none",
                        borderRadius: "12px",
                        boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                      }}
                    />
                    <Bar dataKey="sales" fill="#1DB954" radius={[4, 4, 0, 0]} barSize={24} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Items Sold Today */}
          <Card className="shadow-lg shadow-slate-200/60 border-none bg-white rounded-2xl">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-6">
              <CardTitle className="text-lg font-bold text-[#2D3436]">Items Sold Today</CardTitle>
              <div className="bg-[#E7F6EC] px-3 py-1.5 rounded-full">
                <span className="text-sm font-medium text-slate-500">Total Items </span>
                <span className="text-sm font-bold text-[#1DB954]">({soldItems.reduce((sum, item) => sum + item.quantity, 0)})</span>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-64 overflow-hidden flex flex-col">
                {soldItems.length > 0 ? (
                  <ScrollArea className="flex-1 -mr-4 pr-4">
                    <div className="space-y-4">
                      {soldItems.map((item, index) => {
                        let Icon = Tag;
                        if (item.name.toLowerCase().includes('shake') || item.name.toLowerCase().includes('juice')) Icon = CupSoda;
                        if (item.name.toLowerCase().includes('fruit')) Icon = Citrus;

                        return (
                          <div key={item.name} className="flex items-center justify-between pb-4 border-b border-slate-50 last:border-none group">
                            <div className="flex items-center gap-5">
                              <span className="text-2xl font-bold text-slate-300 w-8">{index + 1}</span>
                              <div className="bg-slate-50 p-2 rounded-xl group-hover:bg-primary/10 transition-colors">
                                <Icon className="h-5 w-5 text-slate-400 group-hover:text-primary transition-colors" />
                              </div>
                              <span className="text-sm font-bold text-[#2D3436] tracking-tight">{item.name}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-sm font-bold text-[#2D3436]">{item.quantity}</span>
                              <span className="text-[11px] font-bold text-slate-400 uppercase">Sold</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground italic">
                    No sales recorded for today
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* 30-Day Trend */}
          <Card className="shadow-lg shadow-slate-200/60 border-none bg-white rounded-2xl">
            <CardHeader>
              <CardTitle className="text-lg font-bold text-[#2D3436]">30-Day Sales Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 pt-4">
                {trendData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trendData}>
                      <defs>
                        <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#1DB954" stopOpacity={0.1} />
                          <stop offset="95%" stopColor="#1DB954" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid vertical={false} strokeDasharray="0" stroke="#f0f0f0" />
                      <XAxis
                        dataKey="date"
                        fontSize={11}
                        axisLine={false}
                        tickLine={false}
                        stroke="#94a3b8"
                      />
                      <YAxis
                        fontSize={11}
                        axisLine={false}
                        tickLine={false}
                        stroke="#94a3b8"
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "white",
                          border: "none",
                          borderRadius: "12px",
                          boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="total"
                        stroke="#1DB954"
                        strokeWidth={3}
                        fillOpacity={1}
                        fill="url(#colorTotal)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground italic">
                    Not enough trend data yet
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Payment Split */}
          <Card className="shadow-lg shadow-slate-200/60 border-none bg-white rounded-2xl">
            <CardHeader>
              <CardTitle className="text-lg font-bold text-[#2D3436]">Payment Split</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                {paymentData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={paymentData}
                        cx="60%"
                        cy="50%"
                        innerRadius={65}
                        outerRadius={90}
                        paddingAngle={0}
                        dataKey="value"
                      >
                        {paymentData.map((_, index) => (
                          <Cell key={`cell-${index}`} fill={CHART_COLORS[index]} stroke="none" />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(value: number) => formatCurrency(value)}
                        contentStyle={{
                          backgroundColor: "white",
                          border: "none",
                          borderRadius: "12px",
                          boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                        }}
                      />
                      <Legend
                        layout="vertical"
                        verticalAlign="middle"
                        align="left"
                        iconType="circle"
                        formatter={(value, entry: any) => (
                          <span className="text-sm font-bold text-[#2D3436]">
                            {value} <span className="text-muted-foreground ml-1 font-normal">
                              {((entry.payload.value / stats.salesToday) * 100).toFixed(0)}%
                            </span>
                          </span>
                        )}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground italic">
                    No payment data recorded
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}