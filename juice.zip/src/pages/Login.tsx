import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useNavigate, useLocation } from "react-router-dom";
import juiceJungleLogo from "@/assets/juice-jungle-logo.jpg";
import { Lock, Mail, Loader2 } from "lucide-react";

export default function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();

    const from = location.state?.from?.pathname || "/";

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);

        try {
            const { error } = await supabase.auth.signInWithPassword({
                email,
                password,
            });

            if (error) {
                toast.error(error.message);
            } else {
                toast.success("Welcome back to Juice Jungle!");
                navigate(from, { replace: true });
            }
        } catch (error: any) {
            toast.error("An unexpected error occurred");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-[#F8FAFB] flex items-center justify-center p-4">
            <div className="w-full max-w-md animate-fade-in">
                <div className="flex flex-col items-center mb-8">
                    <div className="bg-white p-4 rounded-3xl shadow-premium mb-4">
                        <img
                            src={juiceJungleLogo}
                            alt="Juice Jungle"
                            className="h-16 w-16 rounded-2xl object-cover"
                        />
                    </div>
                    <h1 className="text-4xl font-serif text-[#2D3436] tracking-tight">
                        Juice <span className="text-[#1DB954]">Jungle</span>
                    </h1>
                    <p className="text-muted-foreground font-medium mt-2">Premium POS Management</p>
                </div>

                <Card className="border-none shadow-premium rounded-3xl overflow-hidden bg-white">
                    <CardHeader className="pt-8 px-8 pb-0">
                        <CardTitle className="text-2xl font-serif text-[#2D3436]">Welcome Back</CardTitle>
                        <CardDescription>Enter your credentials to access the POS</CardDescription>
                    </CardHeader>
                    <CardContent className="p-8">
                        <form onSubmit={handleLogin} className="space-y-6">
                            <div className="space-y-2">
                                <Label htmlFor="email">Email Address</Label>
                                <div className="relative group">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-[#1DB954] transition-colors" />
                                    <Input
                                        id="email"
                                        type="email"
                                        placeholder="admin@juicejungle.com"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        className="pl-10 h-12 bg-slate-50 border-none rounded-xl focus-visible:ring-1 focus-visible:ring-[#1DB954]/20"
                                        required
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="password">Password</Label>
                                <div className="relative group">
                                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-[#1DB954] transition-colors" />
                                    <Input
                                        id="password"
                                        type="password"
                                        placeholder="••••••••"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        className="pl-10 h-12 bg-slate-50 border-none rounded-xl focus-visible:ring-1 focus-visible:ring-[#1DB954]/20"
                                        required
                                    />
                                </div>
                            </div>

                            <Button
                                type="submit"
                                className="w-full h-12 bg-[#1DB954] hover:bg-[#1aab4d] text-white font-bold rounded-xl shadow-lg shadow-green-100 transition-all active:scale-[0.98]"
                                disabled={isLoading}
                            >
                                {isLoading ? (
                                    <Loader2 className="h-5 w-5 animate-spin" />
                                ) : (
                                    "Sign In to Dashboard"
                                )}
                            </Button>
                        </form>
                    </CardContent>
                </Card>

                <p className="text-center mt-8 text-sm text-muted-foreground font-medium">
                    Protected by Supabase Encryption
                </p>
            </div>
        </div>
    );
}
