import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Bill, BillItem } from "@/types/pos";
import { Calendar, Receipt, Banknote, Smartphone, Package, Eye, ChevronLeft, ChevronRight } from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, addMonths } from "date-fns";

type FilterType = "day" | "month" | "all";

export default function History() {
  const [filterType, setFilterType] = useState<FilterType>("day");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [selectedMonth, setSelectedMonth] = useState(new Date());
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);

  // Fetch all bills based on filter
  const { data: bills = [], isLoading } = useQuery({
    queryKey: ["history-bills", filterType, selectedDate, selectedMonth.toISOString()],
    queryFn: async () => {
      let query = supabase.from("bills").select("*").order("date_time", { ascending: false });

      if (filterType === "day") {
        query = query.eq("business_date", selectedDate);
      } else if (filterType === "month") {
        const start = format(startOfMonth(selectedMonth), "yyyy-MM-dd");
        const end = format(endOfMonth(selectedMonth), "yyyy-MM-dd");
        query = query.gte("business_date", start).lte("business_date", end);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Bill[];
    },
  });

  // Fetch bill items for selected bill
  const { data: billItems = [] } = useQuery({
    queryKey: ["bill-items-detail", selectedBill?.id],
    enabled: !!selectedBill,
    queryFn: async () => {
      if (!selectedBill) return [];
      const { data, error } = await supabase
        .from("bill_items")
        .select("*, menu_items(name)")
        .eq("bill_id", selectedBill.id);

      if (error) throw error;
      return data as (BillItem & { menu_items: { name: string } })[];
    },
  });

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(value);

  const formatDateTime = (dateStr: string) =>
    format(new Date(dateStr), "dd MMM yyyy, hh:mm a");

  const formatDate = (dateStr: string) =>
    format(new Date(dateStr), "dd MMM yyyy");

  // Calculate totals for current filter
  const totalSales = bills.reduce((sum, bill) => sum + Number(bill.total_amount), 0);
  const totalOrders = bills.length;
  const totalParcel = bills.reduce((sum, bill) => sum + Number(bill.total_parcel_collected), 0);
  const cashTotal = bills.filter(b => b.payment_method === "Cash").reduce((sum, b) => sum + Number(b.total_amount), 0);
  const upiTotal = bills.filter(b => b.payment_method === "UPI").reduce((sum, b) => sum + Number(b.total_amount), 0);

  return (
    <AppLayout>
      <div className="space-y-8 animate-fade-in">
        {/* Clean Serif Header */}
        <div>
          <h1 className="text-4xl font-serif text-[#2D3436] mb-1 tracking-tight">Bill History</h1>
          <p className="text-muted-foreground text-sm font-semibold">View and filter all your past transactions</p>
        </div>

        {/* Filters */}
        <Card className="border-none shadow-premium rounded-2xl bg-white">
          <CardContent className="py-4">
            <div className="flex flex-wrap gap-4 items-end">
              <div className="space-y-2">
                <Label>Filter By</Label>
                <Select value={filterType} onValueChange={(v) => setFilterType(v as FilterType)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="day">Day</SelectItem>
                    <SelectItem value="month">Month</SelectItem>
                    <SelectItem value="all">All Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {filterType === "day" && (
                <div className="space-y-2">
                  <Label>Select Date</Label>
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-44"
                  />
                </div>
              )}

              {filterType === "month" && (
                <div className="space-y-2">
                  <Label>Select Month</Label>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setSelectedMonth(subMonths(selectedMonth, 1))}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <div className="w-32 text-center font-medium">
                      {format(selectedMonth, "MMM yyyy")}
                    </div>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setSelectedMonth(addMonths(selectedMonth, 1))}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="shadow-premium border-none bg-white rounded-2xl overflow-hidden">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-[#E7F6EC] p-2.5 rounded-xl">
                <Receipt className="h-5 w-5 text-[#1DB954]" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Total Sales</p>
                <div className="text-lg font-black text-[#1DB954]">{formatCurrency(totalSales)}</div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-premium border-none bg-white rounded-2xl">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-[#E7F6F3] p-2.5 rounded-xl">
                <Calendar className="h-5 w-5 text-[#1DB9AC]" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Orders</p>
                <div className="text-xl font-black text-[#2D3436]">{totalOrders}</div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-premium border-none bg-white rounded-2xl">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-[#E7F6EC] p-2.5 rounded-xl">
                <Package className="h-5 w-5 text-[#1DB954]" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Parcel</p>
                <div className="text-lg font-black text-[#2D3436]">{formatCurrency(totalParcel)}</div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-premium border-none bg-white rounded-2xl">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-[#DEEFDE] p-2.5 rounded-xl">
                <Banknote className="h-5 w-5 text-[#1DB954]" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Cash</p>
                <div className="text-lg font-black text-[#2D3436]">{formatCurrency(cashTotal)}</div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-premium border-none bg-white rounded-2xl">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="bg-[#E7F6EC] p-2.5 rounded-xl">
                <Smartphone className="h-5 w-5 text-[#1DB954]" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">UPI</p>
                <div className="text-lg font-black text-[#2D3436]">{formatCurrency(upiTotal)}</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bills List */}
        <Card className="border-none shadow-premium rounded-2xl bg-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl font-bold text-[#2D3436]">
              <Calendar className="h-5 w-5 text-primary" />
              {filterType === "day" && `Bills for ${formatDate(selectedDate)}`}
              {filterType === "month" && `Bills for ${format(selectedMonth, "MMMM yyyy")}`}
              {filterType === "all" && "All Bills"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-muted-foreground">Loading bills...</div>
            ) : bills.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Receipt className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No bills found for this period</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[500px] overflow-y-auto">
                {bills.map((bill) => (
                  <div
                    key={bill.id}
                    className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg hover:bg-secondary/50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <Receipt className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <div className="font-bold text-lg">Bill #{bill.bill_number}</div>
                        <div className="text-sm text-muted-foreground">
                          {formatDateTime(bill.date_time)}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="font-bold text-lg text-primary">
                          {formatCurrency(Number(bill.total_amount))}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          {bill.payment_method === "Cash" ? (
                            <Banknote className="h-4 w-4" />
                          ) : (
                            <Smartphone className="h-4 w-4" />
                          )}
                          {bill.payment_method}
                          {Number(bill.total_parcel_collected) > 0 && (
                            <span className="ml-2 flex items-center gap-1">
                              <Package className="h-3 w-3" />
                              +{formatCurrency(Number(bill.total_parcel_collected))}
                            </span>
                          )}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setSelectedBill(bill)}
                        className="touch-action-manipulation"
                      >
                        <Eye className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Bill Detail Dialog */}
        <Dialog open={!!selectedBill} onOpenChange={(open) => !open && setSelectedBill(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Receipt className="h-5 w-5 text-primary" />
                Bill #{selectedBill?.bill_number}
              </DialogTitle>
            </DialogHeader>
            {selectedBill && (
              <div className="space-y-4">
                <div className="text-sm text-muted-foreground">
                  {formatDateTime(selectedBill.date_time)}
                </div>

                {/* Items */}
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {billItems.map((item) => (
                    <div key={item.id} className="flex justify-between p-2 bg-secondary/30 rounded">
                      <div>
                        <div className="font-medium">{item.menu_items?.name || "Unknown Item"}</div>
                        <div className="text-sm text-muted-foreground">
                          {item.quantity} × {formatCurrency(Number(item.price_per_unit))}
                          {item.parcel_quantity > 0 && (
                            <span className="ml-2">
                              (Parcel: {item.parcel_quantity})
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">{formatCurrency(Number(item.line_total))}</div>
                        {item.parcel_total > 0 && (
                          <div className="text-xs text-muted-foreground">
                            incl. {formatCurrency(Number(item.parcel_total))} parcel
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Totals */}
                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Subtotal</span>
                    <span>{formatCurrency(Number(selectedBill.subtotal))}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Parcel Charges</span>
                    <span>{formatCurrency(Number(selectedBill.total_parcel_collected))}</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span className="text-primary">{formatCurrency(Number(selectedBill.total_amount))}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground pt-2">
                    {selectedBill.payment_method === "Cash" ? (
                      <Banknote className="h-4 w-4" />
                    ) : (
                      <Smartphone className="h-4 w-4" />
                    )}
                    Paid via {selectedBill.payment_method}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}