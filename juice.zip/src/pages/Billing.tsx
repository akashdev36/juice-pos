import { useState, useCallback, useRef, useEffect } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useMenuItems } from "@/hooks/useMenuItems";
import { useBills } from "@/hooks/useBills";
import { useCategories } from "@/hooks/useCategories";
import { OrderItem, PaymentMethod } from "@/types/pos";
import { Plus, Minus, Trash2, Search, Banknote, QrCode, Smartphone, Package } from "lucide-react";
import { toast } from "sonner";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import juiceHeroBg from "@/assets/juice-hero-bg.jpg";

const PARCEL_CHARGE = 5;

export default function Billing() {
  const { activeMenuItems, isLoading: menuLoading } = useMenuItems();
  const { createBill } = useBills();
  const { categories } = useCategories();
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [order, setOrder] = useState<OrderItem[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null);
  const [applyParcelToAll, setApplyParcelToAll] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [order]);

  const filteredItems = activeMenuItems.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === "all" || item.category_id === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const isEmoji = (str: string) => {
    return /\p{Emoji}/u.test(str) && str.length <= 4;
  };

  const addToOrder = (menuItem: typeof activeMenuItems[0]) => {
    setOrder((prev) => {
      const existing = prev.find((o) => o.menuItem.id === menuItem.id);
      if (existing) {
        return prev.map((o) =>
          o.menuItem.id === menuItem.id ? { ...o, quantity: o.quantity + 1 } : o
        );
      }
      return [...prev, { menuItem, quantity: 1, isParcel: false, parcelQuantity: 0 }];
    });
  };

  const updateQuantity = (menuItemId: string, delta: number) => {
    setOrder((prev) => {
      const newOrder = prev
        .map((o) => {
          if (o.menuItem.id === menuItemId) {
            const newQty = o.quantity + delta;
            if (newQty <= 0) return null;
            return {
              ...o,
              quantity: newQty,
              parcelQuantity: Math.min(o.parcelQuantity, newQty),
            };
          }
          return o;
        })
        .filter(Boolean) as OrderItem[];
      if (newOrder.length === 0) setPaymentMethod(null);
      return newOrder;
    });
  };

  const removeFromOrder = (menuItemId: string) => {
    setOrder((prev) => {
      const newOrder = prev.filter((o) => o.menuItem.id !== menuItemId);
      if (newOrder.length === 0) setPaymentMethod(null);
      return newOrder;
    });
  };

  const toggleItemParcel = (menuItemId: string) => {
    if (applyParcelToAll) return;
    setOrder((prev) =>
      prev.map((o) =>
        o.menuItem.id === menuItemId
          ? {
            ...o,
            isParcel: !o.isParcel,
            parcelQuantity: !o.isParcel ? o.quantity : 0,
          }
          : o
      )
    );
  };

  const updateParcelQuantity = (menuItemId: string, qty: number) => {
    if (applyParcelToAll) return;
    setOrder((prev) =>
      prev.map((o) =>
        o.menuItem.id === menuItemId
          ? {
            ...o,
            parcelQuantity: Math.max(0, Math.min(qty, o.quantity)),
            isParcel: qty > 0,
          }
          : o
      )
    );
  };

  // Calculate totals
  const subtotal = order.reduce((sum, o) => sum + o.quantity * o.menuItem.price, 0);
  const parcelCharges = order.reduce((sum, o) => {
    const parcelQty = applyParcelToAll ? o.quantity : o.parcelQuantity;
    return sum + parcelQty * PARCEL_CHARGE;
  }, 0);
  const total = subtotal + parcelCharges;

  const handlePaymentWithMethod = () => {
    if (order.length === 0) {
      toast.error("Add items to the order first");
      return;
    }

    if (!paymentMethod) {
      toast.error("Please select a payment method");
      return;
    }

    createBill.mutate(
      {
        items: order,
        paymentMethod: paymentMethod,
        applyParcelToAll,
      },
      {
        onSuccess: () => {
          setOrder([]);
          setApplyParcelToAll(false);
          setPaymentMethod(null);
        },
      }
    );
  };

  // Memoized handlers
  const handleUpdateQuantity = useCallback((menuItemId: string, delta: number) => {
    updateQuantity(menuItemId, delta);
  }, []);

  const handleRemoveFromOrder = useCallback((menuItemId: string) => {
    removeFromOrder(menuItemId);
  }, []);

  const handleToggleParcel = useCallback((menuItemId: string) => {
    toggleItemParcel(menuItemId);
  }, [applyParcelToAll]);

  const handleParcelQtyChange = useCallback((menuItemId: string, qty: number) => {
    updateParcelQuantity(menuItemId, qty);
  }, [applyParcelToAll]);

  const truncateByWords = (text: string, maxWords: number = 3) => {
    const words = text.split(" ");
    if (words.length > maxWords) {
      return words.slice(0, maxWords).join(" ") + "...";
    }
    return text;
  };

  return (
    <TooltipProvider>
      <AppLayout>
        <div className="relative min-h-[calc(100vh-80px)] -m-4 md:-m-6 flex flex-col">
          {/* Content area */}
          <div className="flex-1 relative bg-background">

            {/* Main content */}
            <div className="relative z-10 p-3 md:p-4 h-full bg-[#F8FAFB]">
              <div className="grid lg:grid-cols-3 gap-5 h-full animate-fade-in">
                {/* Menu Panel - Left side (takes 2/3 of space) */}
                <div className="lg:col-span-2 flex flex-col bg-white shadow-premium rounded-2xl p-6 h-[calc(100vh-100px)]">
                  <div className="flex items-center gap-4 mb-4">
                    <h2 className="text-3xl font-serif text-[#2D3436] whitespace-nowrap leading-none tracking-tight">Menu</h2>

                    {/* Search */}
                    <div className="relative flex-1 max-w-[180px]">
                      <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                      <Input
                        placeholder="Search..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="pl-8 h-8 bg-muted/50 border-border text-xs"
                      />
                    </div>

                    {/* Category Pills - Horizontal Scroll */}
                    <div className="flex-1 overflow-x-auto no-scrollbar">
                      <div className="flex gap-1 pb-1 pt-1 min-w-max">
                        <Button
                          variant={categoryFilter === "all" ? "default" : "outline"}
                          size="sm"
                          onClick={() => setCategoryFilter("all")}
                          className="rounded-full h-7 px-3 text-[10px] font-medium"
                        >
                          All
                        </Button>
                        {categories.map((cat) => (
                          <Button
                            key={cat.id}
                            variant={categoryFilter === cat.id ? "default" : "outline"}
                            size="sm"
                            onClick={() => setCategoryFilter(cat.id)}
                            className="rounded-full h-7 px-3 text-[10px] font-medium whitespace-nowrap"
                          >
                            {cat.name}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Menu Grid */}
                  {menuLoading ? (
                    <div className="flex-1 flex items-center justify-center text-muted-foreground">
                      Loading menu...
                    </div>
                  ) : (
                    <ScrollArea className="flex-1">
                      <div className="grid grid-cols-5 gap-2 pr-2">
                        {filteredItems.map((item) => {
                          const itemColor = item.color || "#22c55e";
                          const orderItem = order.find(o => o.menuItem.id === item.id);
                          const qtyInOrder = orderItem?.quantity || 0;

                          return (
                            <button
                              key={item.id}
                              className="group relative bg-[#F8FAFB] rounded-2xl overflow-hidden border-none shadow-sm hover:shadow-premium transition-all touch-action-manipulation active:scale-[0.98] flex flex-col"
                              onClick={() => addToOrder(item)}
                            >
                              {/* Quantity badge */}
                              {qtyInOrder > 0 && (
                                <span
                                  className="absolute top-1 right-1 w-5 h-5 rounded-full text-xs font-bold flex items-center justify-center text-white shadow z-10"
                                  style={{ backgroundColor: itemColor }}
                                >
                                  {qtyInOrder}
                                </span>
                              )}

                              {/* Product Image - Compact */}
                              <div className="w-full aspect-[4/3] bg-gray-50 overflow-hidden">
                                {item.image_url ? (
                                  isEmoji(item.image_url) ? (
                                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
                                      <span className="text-4xl">{item.image_url}</span>
                                    </div>
                                  ) : (
                                    <img
                                      src={item.image_url}
                                      alt={item.name}
                                      className="w-full h-full object-cover"
                                    />
                                  )
                                ) : (
                                  <div
                                    className="w-full h-full flex items-center justify-center"
                                    style={{ backgroundColor: `${itemColor}15` }}
                                  >
                                    <span className="text-3xl opacity-30">🥤</span>
                                  </div>
                                )}
                              </div>

                              {/* Product Name */}
                              <div className="px-1 py-1.5 bg-white">
                                <span className="font-bold text-[10px] text-[#2D3436] leading-tight line-clamp-1 block text-center uppercase tracking-wider">
                                  {item.name}
                                </span>
                              </div>

                              {/* Price Footer Bar */}
                              <div
                                className="flex items-center justify-between px-3 py-2"
                                style={{ backgroundColor: itemColor }}
                              >
                                <span className="font-black text-white text-xs">
                                  ₹{Number(item.price).toFixed(0)}
                                </span>
                                <div className="w-5 h-5 bg-white/20 rounded-md flex items-center justify-center group-hover:bg-white/30 transition-colors">
                                  <Plus className="h-3 w-3 text-white" />
                                </div>
                              </div>
                            </button>
                          );
                        })}
                        {filteredItems.length === 0 && (
                          <div className="col-span-full text-center py-12 text-muted-foreground">
                            {search || categoryFilter !== "all" ? "No items match" : "No active items"}
                          </div>
                        )}
                      </div>
                    </ScrollArea>
                  )}
                </div>

                {/* Order Summary - Right side (takes 1/3 of space) */}
                <div className="lg:col-span-1 bg-white rounded-2xl shadow-premium border-none flex flex-col h-[calc(100vh-100px)]">
                  {/* Header */}
                  <div className="flex items-center justify-between p-4 border-b border-slate-50">
                    <h2 className="text-xl font-serif text-[#2D3436] tracking-tight">Order</h2>
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-primary" />
                      <Label htmlFor="parcel-all" className="text-xs cursor-pointer">
                        All Parcel
                      </Label>
                      <Switch
                        id="parcel-all"
                        checked={applyParcelToAll}
                        onCheckedChange={setApplyParcelToAll}
                      />
                    </div>
                  </div>

                  {/* Order Items */}
                  <ScrollArea className="flex-1 p-2">
                    {order.length === 0 ? (
                      <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
                        Tap items to add to order
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {order.map((item) => {
                          const lineSubtotal = item.quantity * item.menuItem.price;
                          const parcelQty = applyParcelToAll ? item.quantity : item.parcelQuantity;
                          const lineParcel = parcelQty * PARCEL_CHARGE;

                          return (
                            <div key={item.menuItem.id} className="p-2 bg-secondary/30 rounded-xl border border-white/50">
                              <div className="flex items-center gap-2">
                                {/* Quantity controls */}
                                <div className="flex items-center gap-1 bg-white/80 rounded-lg border border-border/50 p-0.5">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6"
                                    onClick={() => handleUpdateQuantity(item.menuItem.id, -1)}
                                  >
                                    <Minus className="h-2.5 w-2.5" />
                                  </Button>
                                  <span className="w-5 text-center text-xs font-bold">{item.quantity}</span>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6"
                                    onClick={() => handleUpdateQuantity(item.menuItem.id, 1)}
                                  >
                                    <Plus className="h-2.5 w-2.5" />
                                  </Button>
                                </div>

                                {/* Item info */}
                                <div className="flex-1 min-w-0 mr-1">
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <p className="font-bold text-[10px] text-[#2D3436] truncate uppercase tracking-tight leading-none mb-0.5 cursor-help">
                                        {truncateByWords(item.menuItem.name)}
                                      </p>
                                    </TooltipTrigger>
                                    <TooltipContent side="top" className="bg-[#2D3436] text-white border-none text-[10px] font-bold">
                                      <p>{item.menuItem.name}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                  <p className="text-[9px] text-[#1DB954] font-bold">₹{item.menuItem.price}</p>
                                </div>

                                {/* Parcel controls - Integrated in line */}
                                {!applyParcelToAll && (
                                  <div className="flex items-center gap-1.5 px-1.5 border-x border-slate-200/50">
                                    <div className="flex flex-col items-center">
                                      <Switch
                                        checked={item.isParcel}
                                        onCheckedChange={() => handleToggleParcel(item.menuItem.id)}
                                        className="scale-[0.6] data-[state=checked]:bg-[#1DB954]"
                                      />
                                      <span className="text-[7px] font-black uppercase text-muted-foreground mt-0.5">Parcel</span>
                                    </div>

                                    {item.isParcel && (
                                      <div className="flex items-center gap-0.5 bg-white/80 rounded border border-border/30 p-0.5 scale-90">
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-4 w-4"
                                          onClick={() => handleParcelQtyChange(item.menuItem.id, item.parcelQuantity - 1)}
                                        >
                                          <Minus className="h-2 w-2" />
                                        </Button>
                                        <span className="w-3 text-center text-[9px] font-black">{item.parcelQuantity}</span>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-4 w-4"
                                          onClick={() => handleParcelQtyChange(item.menuItem.id, item.parcelQuantity + 1)}
                                        >
                                          <Plus className="h-2 w-2" />
                                        </Button>
                                      </div>
                                    )}
                                  </div>
                                )}

                                {/* Total */}
                                <div className="text-right min-w-[55px] shrink-0 ml-1">
                                  <p className="font-black text-xs text-[#2D3436]">₹{lineSubtotal.toFixed(0)}</p>
                                  {parcelQty > 0 && (
                                    <p className="text-[8px] font-bold text-[#1DB954] tracking-tighter">+{lineParcel} P</p>
                                  )}
                                </div>

                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6 text-destructive hover:bg-destructive/10 shrink-0"
                                  onClick={() => handleRemoveFromOrder(item.menuItem.id)}
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            </div>
                          );
                        })}
                        <div ref={scrollRef} />
                      </div>
                    )}
                  </ScrollArea>

                  {/* Totals and Payment */}
                  <div className="p-3 border-t border-border bg-slate-50/30 space-y-3">
                    {/* Totals */}
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-[10px] font-bold text-muted-foreground uppercase tracking-tight">
                        <span>Parcel: <span className="text-[#2D3436]">₹{parcelCharges.toFixed(2)}</span></span>
                        <span>Subtotal: <span className="text-[#2D3436]">₹{subtotal.toFixed(2)}</span></span>
                      </div>
                      <div className="flex justify-between text-xl font-black pt-1">
                        <span className="text-[#2D3436]">Total</span>
                        <span className="text-[#1DB954]">₹{total.toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Payment Method Selection */}
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <Button
                          variant={paymentMethod === "Cash" ? "default" : "outline"}
                          className={`h-9 text-xs font-bold touch-action-manipulation transition-all ${paymentMethod === "Cash"
                            ? "bg-[#1DB954] text-white shadow-md ring-2 ring-green-100"
                            : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                            }`}
                          onClick={() => setPaymentMethod("Cash")}
                          disabled={order.length === 0 || createBill.isPending}
                        >
                          <Banknote className="h-3.5 w-3.5 mr-2" />
                          Cash
                        </Button>
                        <Button
                          variant={paymentMethod === "UPI" ? "default" : "outline"}
                          className={`h-9 text-xs font-bold touch-action-manipulation transition-all ${paymentMethod === "UPI"
                            ? "bg-[#1DB954] text-white shadow-md ring-2 ring-green-100"
                            : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                            }`}
                          onClick={() => setPaymentMethod("UPI")}
                          disabled={order.length === 0 || createBill.isPending}
                        >
                          <QrCode className="h-3.5 w-3.5 mr-2" />
                          UPI
                        </Button>
                      </div>
                    </div>

                    {/* Final Action Button */}
                    <Button
                      className="w-full h-11 text-sm font-black bg-[#1DB954] hover:bg-[#1aab4d] text-white shadow-lg shadow-green-100 active:scale-[0.98] transition-all"
                      onClick={handlePaymentWithMethod}
                      disabled={order.length === 0 || !paymentMethod || createBill.isPending}
                    >
                      {createBill.isPending ? "Processing..." : `Complete Order - ₹${total.toFixed(0)}`}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </AppLayout>
    </TooltipProvider>
  );
}
